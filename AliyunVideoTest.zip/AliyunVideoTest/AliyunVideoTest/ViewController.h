//
//  ViewController.h
//  AliyunVideoTest
//
//  Created by aa on 2017/11/17.
//  Copyright © 2017年 aa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

