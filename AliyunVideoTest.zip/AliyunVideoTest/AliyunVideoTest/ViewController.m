//
//  ViewController.m
//  AliyunVideoTest
//
//  Created by aa on 2017/11/17.
//  Copyright © 2017年 aa. All rights reserved.
//

#import "ViewController.h"
#import <AliyunPlayer_iOS/AliyunVodPlayerViewSDK/AliyunVodPlayerViewSDK.h>
#import <AFNetworking.h>

@interface ViewController ()<AliyunVodPlayerViewDelegate>
@property (strong, nonatomic) AliyunVodPlayerView *playerView;
@property (strong, nonatomic) NSString *vid;
@property (strong, nonatomic) NSString *playAuth;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //创建播放器对象，AliyunVodPlayerView继承自UIView，可以创建多实例，提供4套皮肤可设置
    self.playerView = [[AliyunVodPlayerView alloc] initWithFrame:CGRectMake(0,20, self.view.frame.size.width, self.view.frame.size.height-20) andSkin:AliyunVodPlayerViewSkinRed];
    //设置播放器代理
    [self.playerView setDelegate:self];
    [self.playerView setAutoPlay:YES];
    //将播放器添加到需要展示的界面上
    [self.view addSubview:self.playerView];
    //本地视频,填写文件路径
    //NSURL *url = [NSURL fileURLWithPath:@""];
    //网络视频，填写网络url地址
    //NSURL *url = [NSURL URLWithString:@"http://dev.vshijian.com/uploads/videos/ef8f1d15b86f56d62b9b7d05346b17c8.mp4"];
    //prepareToPlay:此方法传入的参数是NSURL类型.
    //[playerView playViewPrepareWithURL:url];
    AFHTTPSessionManager *session = [AFHTTPSessionManager manager];
    [session GET:@"http://dev.vshijian.com/api/video/play-auth/1" parameters:nil progress:nil success:^(NSURLSessionDataTask *task, id responseObject) {
        NSLog(@"请求成功");
        self.vid=responseObject[@"data"][@"VideoMeta"][@"VideoId"];
        self.playAuth=responseObject[@"data"][@"PlayAuth"];
        //播放方式三：使用vid+playAuth方式播放（V3.2.0之前版本使用，兼容老用户）
        [self.playerView playViewPrepareWithVid:self.vid playAuth:self.playAuth];
        
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
        NSLog(@"请求失败");
    }];
    
}

- (void)onBackViewClickWithAliyunVodPlayerView:(AliyunVodPlayerView*)playerView{
    //点击播放器界面的返回按钮时触发，可以用来处理界面跳转
    NSLog(@"点击返回");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView*)playerView onPause:(NSTimeInterval)currentPlayTime{
    //点击播放器界面的暂停按钮时触发，可以用来添加暂定时在界面上添加其他元素，如广告图片等
    NSLog(@"点击暂停");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView*)playerView onResume:(NSTimeInterval)currentPlayTime{
    //点击播放界面的恢复按钮时触发，可以用来处理界面上额外添加的元素隐藏等功能
    NSLog(@"点击恢复");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView*)playerView onStop:(NSTimeInterval)currentPlayTime{
    //播放器调用stop时触发
    NSLog(@"调用stop");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView*)playerView onSeekDone:(NSTimeInterval)seekDoneTime{
    //播放器Seek完成时触发，可以用来处理界面的UI元素变化
    NSLog(@"调用Seek");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView*)playerView lockScreen:(BOOL)isLockScreen{
    //点击界面的锁屏按钮时触发，用来和controller交互锁定事件
    NSLog(@"点击界面的锁屏按钮");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView*)playerView onVideoQualityChanged:(AliyunVodPlayerVideoQuality)quality{
    //当清晰度改变后触发，可以用来处理清晰度发生变化时的UI提醒
    NSLog(@"清晰度改变");
}
- (void)aliyunVodPlayerView:(AliyunVodPlayerView *)playerView fullScreen:(BOOL)isFullScreen{
    //当出发全屏旋转后出发，用于配合ViewController来展示横屏全屏、竖屏全屏。
    NSLog(@"全屏旋转");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
